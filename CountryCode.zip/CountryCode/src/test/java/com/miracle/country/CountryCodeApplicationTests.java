package com.miracle.country;

import static io.restassured.RestAssured.get;
import static org.hamcrest.CoreMatchers.equalTo;

import org.junit.BeforeClass;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


import io.restassured.RestAssured;

@SpringBootTest
class CountryCodeApplicationTests {

	 @BeforeClass
	    public static void init() {
	        RestAssured.baseURI = "http://localhost";
	        RestAssured.port = 8080;
	    }
	 
	@Test
	void contextLoads() {
	}
	
	@Test
	public void countryTest() {
	
		
		get("/countryCon/webapi/countryApi/AF")
        .then()
        .body("iso2Code", equalTo("AF"))
        .body("region", equalTo("{\n" + 
        		"			\"id\": \"SAS\",\n" + 
        		"			\"iso2code\": \"8S\",\n" + 
        		"			\"value\": \"South Asia\"\n" + 
        		"		}"))
        .body("incomeLevel", equalTo(" {\n" + 
        		"			\"id\": \"LIC\",\n" + 
        		"			\"iso2code\": \"XM\",\n" + 
        		"			\"value\": \"Low income\"\n" + 
        		"		}"))
        .body("lendingType", equalTo("{\n" + 
        		"			\"id\": \"IDX\",\n" + 
        		"			\"iso2code\": \"XI\",\n" + 
        		"			\"value\": \"IDA\"\n" + 
        		"		}"));

		
		
	}

}

package com.miracle.country.api;

import javax.ws.rs.Path;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.miracle.country.model.IncomeLevel;
import com.miracle.country.model.LendingType;
import com.miracle.country.model.Region;
import com.miracle.country.model.ReturnObject;
import com.miracle.country.service.MyService;

@Controller
@Path("/countryCon")
public class MyController {
	
	@Autowired
	MyService myService;
	
	@GetMapping(value="/countryApi")
	public ReturnObject countryMethod(@PathVariable String countryCode) {
		
		ReturnObject returnObject = null;
		
		try {
			
			//call the web service
			
			String message = myService.callWebService();
			
			Object obj = new JSONParser().parse(message); 
			
			JSONArray joArray = (JSONArray) obj; 
			
			JSONArray countryArray = (JSONArray) joArray.get(1);
			
			for(int i = 0; i< countryArray.size(); i++) {
				
				JSONObject countryObj  = (JSONObject)countryArray.get(i);
				
				if(countryObj.get("iso2Code").equals(countryCode)) {
					
					returnObject = new ReturnObject();
					
					returnObject.setCapitalCity((String)countryObj.get("capitalCity"));
					
					Region region = new Region();
					
					JSONObject regObj = (JSONObject)countryObj.get("region");
					
					region.setId((String)regObj.get("id"));
					region.setIso2code((String)regObj.get("iso2code"));
					region.setValue((String)regObj.get("value"));
					
					returnObject.setRegion(region);
					
					JSONObject incomeObj = (JSONObject)countryObj.get("incomeLevel");
					
					IncomeLevel incomeLevel = new IncomeLevel();
					incomeLevel.setId((String)incomeObj.get("id"));
					incomeLevel.setIso2code((String)incomeObj.get("iso2code"));
					incomeLevel.setValue((String)incomeObj.get("value"));
					
					returnObject.setIncomeLevel(incomeLevel);
					
					JSONObject lendingObj = (JSONObject)countryObj.get("lendingType");
					
					LendingType lendingType = new LendingType();
					lendingType.setId((String)lendingObj.get("id"));
					lendingType.setIso2code((String)lendingObj.get("iso2code"));
					lendingType.setValue((String)lendingObj.get("value"));
					
					returnObject.setLendingType(lendingType);
					
					
				}//end of if
			}//end of for
			
			
		}catch(Exception e) {
			
			e.printStackTrace();
		}
		
		
		return returnObject;
		
	}//end of method

}//end of class

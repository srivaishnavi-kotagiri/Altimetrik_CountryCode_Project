package com.miracle.country.model;

public class ReturnObject {
	
	 String capitalCity;
	 
	 Region region;
	 
	 IncomeLevel incomeLevel;
	 
	 LendingType lendingType;

	public String getCapitalCity() {
		return capitalCity;
	}

	public void setCapitalCity(String capitalCity) {
		this.capitalCity = capitalCity;
	}

	public Region getRegion() {
		return region;
	}

	public void setRegion(Region region) {
		this.region = region;
	}

	public IncomeLevel getIncomeLevel() {
		return incomeLevel;
	}

	public void setIncomeLevel(IncomeLevel incomeLevel) {
		this.incomeLevel = incomeLevel;
	}

	public LendingType getLendingType() {
		return lendingType;
	}

	public void setLendingType(LendingType lendingType) {
		this.lendingType = lendingType;
	}
	
	

	
}

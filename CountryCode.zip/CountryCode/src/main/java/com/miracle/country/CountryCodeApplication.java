package com.miracle.country;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CountryCodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CountryCodeApplication.class, args);
	}

}
